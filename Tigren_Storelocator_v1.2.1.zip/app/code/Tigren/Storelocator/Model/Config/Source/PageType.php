<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class PageType
 *
 * @package Tigren\Storelocator\Model\Config\Source
 */
class PageType implements ArrayInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => '', 'value' => '--Select Type--'],
            ['label' => '1 column', 'value' => '1'],
            ['label' => '2 columns with map on the right', 'value' => '2']
        ];
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return [
            '' => '--Select Type--',
            '1' => '1 column',
            '2' => '2 columns with map on the right'
        ];
    }
}
