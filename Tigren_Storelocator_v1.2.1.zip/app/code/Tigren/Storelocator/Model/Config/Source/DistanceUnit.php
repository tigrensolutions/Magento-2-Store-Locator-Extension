<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class DistanceUnit
 *
 * @package Tigren\Storelocator\Model\Config\Source
 */
class DistanceUnit implements ArrayInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => '', 'value' => '--Select Unit--'],
            ['label' => 'Mile', 'value' => '0'],
            ['label' => 'Kilometer', 'value' => '1']
        ];
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return [
            '' => '--Select Type--',
            '0' => 'Mile',
            '1' => 'Kilometer'
        ];
    }
}
