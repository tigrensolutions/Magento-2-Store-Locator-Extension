<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Model\Store\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Tigren\Storelocator\Model\Store;

/**
 * Class IsActive
 *
 * @package Tigren\Storelocator\Model\Store\Source
 */
class IsActive implements OptionSourceInterface
{
    /**
     * @var Store
     */
    protected $_store;

    /**
     * Constructor
     *
     * @param Store $store
     */
    public function __construct(Store $store)
    {
        $this->_store = $store;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_store->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}
