<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Controller\Adminhtml\Store;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Stdlib\DateTime\Filter\Date;
use Magento\Framework\View\Result\PageFactory;
use Magento\MediaStorage\Model\File\Uploader;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Psr\Log\LoggerInterface;
use RuntimeException;
use Tigren\Storelocator\Helper\Data;
use Tigren\Storelocator\Model\Store;

/**
 * Class Save
 *
 * @package Tigren\Storelocator\Controller\Adminhtml\Store
 */
class Save extends Action
{
    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * Date filter instance
     *
     * @var Date
     */
    protected $_dateFilter;

    /**
     * @var DateTime
     */
    protected $_date;

    /**
     * File system
     *
     * @var Filesystem
     */
    protected $_fileSystem;
    /**
     * File Uploader factory
     *
     * @var UploaderFactory
     */
    protected $_fileUploaderFactory;

    /**
     * @var LoggerInterface
     */
    protected $_logger;

    /**
     * @var Data
     */
    protected $_storelocatorHelper;

    /**
     * @param Action\Context $context
     */
    public function __construct(
        Action\Context $context,
        Registry $coreRegistry,
        ForwardFactory $resultForwardFactory,
        PageFactory $resultPageFactory,
        Date $dateFilter,
        DateTime $date,
        Filesystem $fileSystem,
        UploaderFactory $fileUploaderFactory,
        LoggerInterface $logger,
        Data $storelocatorHelper
    ) {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
        $this->resultForwardFactory = $resultForwardFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->_dateFilter = $dateFilter;
        $this->_date = $date;
        $this->_fileSystem = $fileSystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_logger = $logger;
        $this->_storelocatorHelper = $storelocatorHelper;
    }

    /**
     * Save action
     *
     * @return ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /**
 * @var Redirect $resultRedirect
*/
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            /**
 * @var Store $model
*/
            $model = $this->_objectManager->create('Tigren\Storelocator\Model\Store');

            $id = $this->getRequest()->getParam('store_locator_id');

            if ($id) {
                $model->load($id);
                if ($id != $model->getId()) {
                    throw new LocalizedException(__('The wrong store is specified.'));
                }
            }

            if (!$data['longitude'] || !$data['latitude'] || $data['address'] != $model->getAddress()) {
                $address = urlencode($data['address']);
                $json = $this->_storelocatorHelper->getJsonData($address);
                $data['latitude'] = strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'});
                $data['longitude'] = strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'});
            }

            //upload icon
            $path = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)
                ->getAbsolutePath('tigren/storelocator/');
            if (empty($data['is_delete_icon'])) {
                $storeImage = !empty($_FILES['icon']['name']);
                try {
                    // remove the old file
                    if ($storeImage) {
                        $oldName = !empty($data['old_icon']) ? $data['old_icon'] : '';
                        if ($oldName) {
                            @unlink($path . $oldName);
                        }

                        //find the first available name
                        $newName = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $_FILES['icon']['name']);
                        if (substr($newName, 0, 1) == '.') { // all non-english symbols
                            $newName = 'store_' . $newName;
                        }
                        $i = 0;
                        while (file_exists($path . $newName)) {
                            $newName = ++$i . '_' . $newName;
                        }

                        /**
 * @var $uploader Uploader
*/
                        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'icon']);
                        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                        $uploader->setAllowRenameFiles(true);
                        $uploader->save($path, $newName);

                        $data['icon'] = $newName;
                    } else {
                        $oldName = !empty($data['old_icon']) ? $data['old_icon'] : '';
                        $data['icon'] = $oldName;
                    }
                } catch (Exception $e) {
                    if ($e->getCode() != Uploader::TMP_NAME_EMPTY) {
                        $this->_logger->critical($e);
                    }
                }
            }

            //Process delete icon
            if (!empty($data['is_delete_icon'])) {
                $oldName = !empty($data['old_icon']) ? $data['old_icon'] : '';
                if ($oldName) {
                    @unlink($path . $oldName);
                }
                $data['icon'] = '';
            }

            $model->setData($data);

            $model->setStores($data['stores']);

            $tagArray = explode(',', $data['tags']);
            $tagArray = array_map('trim', $tagArray);
            $model->setTags($tagArray);

            $this->_eventManager->dispatch(
                'storelocator_store_prepare_save',
                ['store' => $model, 'request' => $this->getRequest()]
            );

            try {
                $model->save();
                $this->messageManager->addSuccess(__('You saved this Store.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath(
                        '*/*/edit',
                        ['store_locator_id' => $model->getId(), '_current' => true]
                    );
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the store.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath(
                '*/*/edit',
                ['store_locator_id' => $this->getRequest()->getParam('store_locator_id')]
            );
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Tigren_Storelocator::mange_store_locator');
    }
}
