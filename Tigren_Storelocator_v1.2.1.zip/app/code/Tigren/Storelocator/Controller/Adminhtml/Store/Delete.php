<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Controller\Adminhtml\Store;

use Exception;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;
use Tigren\Storelocator\Model\Store;

/**
 * Class Delete
 *
 * @package Tigren\Storelocator\Controller\Adminhtml\Store
 */
class Delete extends Action
{
    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('store_locator_id');
        if ($id) {
            try {
                /**
 * @var Store $model
*/
                $model = $this->_objectManager->create('Tigren\Storelocator\Model\Store');
                $model->load($id);
                $model->delete();
                $this->_redirect('storelocator/*/');
                return;
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (Exception $e) {
                $this->messageManager->addError(
                    __('We can\'t delete this store right now. Please review the log and try again.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_redirect(
                    'storelocator/*/edit',
                    ['store_locator_id' => $this->getRequest()->getParam('store_locator_id')]
                );
                return;
            }
        }
        $this->messageManager->addError(__('We can\'t find a rule to delete.'));
        $this->_redirect('storelocator/*/');
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Tigren_Storelocator::mange_store_locator');
    }
}
