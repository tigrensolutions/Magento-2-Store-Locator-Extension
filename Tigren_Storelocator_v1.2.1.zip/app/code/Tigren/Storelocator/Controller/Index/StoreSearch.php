<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\UrlFactory;
use Magento\Framework\UrlInterface;
use Tigren\Storelocator\Helper\Data;

/**
 * Class StoreSearch
 *
 * @package Tigren\Storelocator\Controller\Index
 */
class StoreSearch extends Action
{
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var UrlInterface
     */
    protected $_urlBuilder;

    /**
     * @var Data
     */
    protected $_storelocatorHelper;

    /**
     * @param Context     $context
     * @param JsonFactory $resultJsonFactory
     * @param array       $searchModules
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        UrlFactory $urlFactory,
        Data $storelocatorHelper
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_storelocatorHelper = $storelocatorHelper;
        $this->_urlBuilder = $urlFactory->create();
    }

    /**
     * Global Search Action
     *
     * @return Json
     */
    public function execute()
    {
        $query = $this->getRequest()->getParam('q', '');
        //$query = 'Cambridge';
        $address = urlencode($query);

        $googleGeoApiUrl = $this->_storelocatorHelper->getGoogleGeoApiUrl();
        if ($googleGeoApiUrl != '') {
            $url = $googleGeoApiUrl . "?address=$address&sensor=false";
        } else {
            $url = 'http://maps.googleapis.com/maps/api/geocode/json?address=' . $address . '&sensor=false';
        }

        $rCURL = curl_init();
        curl_setopt($rCURL, CURLOPT_URL, $url);
        curl_setopt($rCURL, CURLOPT_HEADER, 0);
        curl_setopt($rCURL, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
        curl_setopt($rCURL, CURLOPT_RETURNTRANSFER, 1);
        $jsonData = curl_exec($rCURL);

        $data = json_decode($jsonData, true);

        $result = [];
        foreach ($data['results'] as $item) {
            $result[] = [
                'address' => $item['formatted_address'],
                'url' => $this->_urlBuilder->getUrl(
                    'storelocator',
                    ['_current' => true, 'q' => urlencode($item['formatted_address'])]
                )
            ];
        }

        // return did you mean from item 2nd
        $result = array_slice($result, 1, 4);

        /**
 * @var Json $resultJson
*/
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($result);
    }
}
