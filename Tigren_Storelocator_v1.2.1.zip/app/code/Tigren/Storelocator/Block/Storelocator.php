<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Block;

use Magento\Catalog\Model\CategoryFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\Timezone;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use Tigren\Storelocator\Helper\Data;
use Tigren\Storelocator\Model\ResourceModel\Tag\CollectionFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\Session\SessionManagerInterface;

/**
 * Class Storelocator
 *
 * @package Tigren\Storelocator\Block
 */
class Storelocator extends Template
{
    /**
     * Registry object.
     *
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * block collecion factory.
     *
     * @var \Tigren\Storelocator\Model\ResourceModel\Store\CollectionFactory
     */
    protected $_storeCollectionFactory;

    /**
     * block collecion factory.
     *
     * @var CollectionFactory
     */
    protected $_tagCollectionFactory;

    /**
     * scope config.
     *
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * stdlib timezone.
     *
     * @var Timezone
     */
    protected $_stdTimezone;

    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * @var SessionManagerInterface
     */
    protected $_sessionManager;

    /**
     * @var Data
     */
    protected $_storelocatorHelper;

    /**
     * @var
     */
    protected $_stores;

    /**
     * @param Context                                                          $context
     * @param Registry                                                         $coreRegistry
     * @param \Tigren\Storelocator\Model\ResourceModel\Store\CollectionFactory $storeCollectionFactory
     * @param CategoryFactory                                                  $categoryFactory
     * @param Timezone                                                         $_stdTimezone
     * @param StoreManagerInterface                                            $storeManager
     * @param array                                                            $data
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        Timezone $_stdTimezone,
        Session $customerSession,
        \Tigren\Storelocator\Model\ResourceModel\Store\CollectionFactory $storeCollectionFactory,
        CollectionFactory $tagCollectionFactory,
        Data $storelocatorHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_coreRegistry = $coreRegistry;
        $this->_stdTimezone = $_stdTimezone;
        $this->_customerSession = $customerSession;
        $this->_sessionManager = $context->getSession();
        $this->_storeCollectionFactory = $storeCollectionFactory;
        $this->_tagCollectionFactory = $tagCollectionFactory;
        $this->_storelocatorHelper = $storelocatorHelper;

        $this->_scopeConfig = $context->getScopeConfig();
        $this->_storeManager = $context->getStoreManager();

        $pageType = $this->_storelocatorHelper->getPageType();
        if ($pageType == 2) {
            $this->setTemplate('2columns.phtml');
        } else {
            $this->setTemplate('1column.phtml');
        }
    }

    /**
     * @return Data
     */
    public function getStorelocatorHelper()
    {
        return $this->_storelocatorHelper;
    }

    /**
     * @return string
     */
    public function getScriptUrl()
    {
        return "//maps.googleapis.com/maps/api/js?key="
            . $this->_storelocatorHelper->getGoogleApiKey()
            . "&sensor=false&libraries=geometry,places";
    }

    /**
     * @return mixed
     */
    public function getStoreQuery()
    {
        return $this->_sessionManager->getData('store_query');
    }

    /**
     * @return bool
     */
    public function displaySearchForm()
    {
        return $this->_storelocatorHelper->displaySearchForm();
    }

    /**
     * @return $this|Template
     * @throws LocalizedException
     */
    public function _prepareLayout()
    {
        parent::_prepareLayout();

        $showPerPageOptions = $this->_storelocatorHelper->getShowPerPageOptions();
        if (empty($showPerPageOptions)) {
            $showPerPageOptions = [10 => 10, 20 => 20, 30 => 30];
        }

        if ($this->getStores()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'storelocator.store.pager'
            )->setAvailableLimit($showPerPageOptions);

            $defaultLimit = $this->_storelocatorHelper->getDefaultShowPerPage();
            if (!$limit = $this->getRequest()->getParam($pager->getLimitVarName()) && $defaultLimit) {
                $pager->setLimit($defaultLimit);
            }

            $pager->setShowAmounts(false)
                ->setShowPerPage(true)
                ->setCollection($this->getStores());

            $this->setChild('pager', $pager);
            $this->getStores()->load();
        }

        return $this;
    }

    /**
     * @return mixed
     */
    public function getStores()
    {
        if ($this->_stores === null) {
            $data = $this->getRequest()->getParams();
            $_collection = $this->_storeCollectionFactory->create()
                ->addFieldToSelect(
                    '*'
                );

            $centerLatitude = $_collection->getFirstItem()->getLatitude();
            $centerLongitude = $_collection->getFirstItem()->getLongitude();
            $this->_sessionManager->setData('centerLatitude', $centerLatitude);
            $this->_sessionManager->setData('centerLongitude', $centerLongitude);
            $this->_sessionManager->setData('store_query', '');

            if (!empty($data['q'])) {
                if (!empty($data['d'])) {
                    $radius = $data['d'];
                } else {
                    $radius = $this->_storelocatorHelper->getSearchRadius();
                }
                $storeIds = [];
                if ($data['q']) {
                    $address = urlencode($data['q']);
                    $json = $this->_storelocatorHelper->getJsonData($address);
                    $centerLatitude = strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'});
                    $centerLongitude = strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'});
                    foreach ($_collection as $item) {
                        if ($this->_storelocatorHelper->distanceBetweenTwoCoord(
                            $item->getLatitude(),
                            $item->getLongitude(),
                            $centerLatitude,
                            $centerLongitude
                        ) <= $radius
                        ) {
                            $storeIds[] = $item->getId();
                        }
                    }
                }
                $_collection->addFieldToFilter('store_locator_id', ['in' => $storeIds]);
                $this->_sessionManager->setData('store_query', $data['q']);
                $this->_sessionManager->setData('centerLatitude', $centerLatitude);
                $this->_sessionManager->setData('centerLongitude', $centerLongitude);
                $_collection->addExpressionFieldToSelect(
                    'distance',
                    '(3956 * 2 * ASIN(SQRT( POWER(SIN(({{latitude}} - ' . $centerLatitude . ') *  pi()/180 / 2), 2) +COS({{latitude}} * pi()/180) * COS(' . $centerLatitude . ' * pi()/180) * POWER(SIN(({{longitude}} - ' . $centerLongitude . ') * pi()/180 / 2), 2) )))',
                    ['latitude' => 'latitude', 'longitude' => 'longitude']
                );
                $_collection->getSelect()->order('distance', 'ASC');
            }

            if (!empty($data['tag'])) {
                // filter collection by tag
                $listStoreIds = $this->_storelocatorHelper->filterStoreByTag($data['tag']);
                $_collection->addFieldToFilter('store_locator_id', ['in' => $listStoreIds]);
            }

            if (isset($data['current_latitude']) && isset($data['current_longitude'])) {
                // find the neariest store
                if ($data['current_latitude'] && $data['current_longitude']) {
                    $centerLatitude = strval($data['current_latitude']);
                    $centerLongitude = strval($data['current_longitude']);
                    $this->_sessionManager->setData('store_query', "HERE");
                    $this->_sessionManager->setData('centerLatitude', $centerLatitude);
                    $this->_sessionManager->setData('centerLongitude', $centerLongitude);
                    $_collection->addExpressionFieldToSelect(
                        'distance',
                        '(3956 * 2 * ASIN(SQRT( POWER(SIN(({{latitude}} - ' . $centerLatitude . ') *  pi()/180 / 2), 2) +COS({{latitude}} * pi()/180) * COS(' . $centerLatitude . ' * pi()/180) * POWER(SIN(({{longitude}} - ' . $centerLongitude . ') * pi()/180 / 2), 2) )))',
                        ['latitude' => 'latitude', 'longitude' => 'longitude']
                    );
                    $_collection->getSelect()->order('distance', 'ASC');
                }
            }

            $this->_stores = $_collection;
        }

        return $this->_stores;
    }

    /**
     * @return mixed
     */
    public function getStoreLimit()
    {
        return $this->_sessionManager->getData('store_query');
    }

    /**
     * @return array
     */
    public function getDistancesToStores()
    {
        $centerLatitude = $this->_sessionManager->getData('centerLatitude');
        $centerLongitude = $this->_sessionManager->getData('centerLongitude');

        if (isset($centerLatitude) && isset($centerLongitude)) {
            $storeDistances = [];

            foreach ($this->getStores()->getData() as $item) {
                $storeDistances[$item['store_locator_id']] = $this->_storelocatorHelper->distanceBetweenTwoCoord(
                    $item['latitude'],
                    $item['longitude'],
                    $centerLatitude,
                    $centerLongitude
                );
            }
            asort($storeDistances);

            return $storeDistances;
        }
    }

    /**
     * @return string
     */
    public function getSearchQueryText()
    {
        return (string)$this->getRequest()->getParam('q');
    }

    /**
     * @return string
     */
    public function getSearchRadius()
    {
        return (string)$this->getRequest()->getParam('d');
    }

    /**
     * @return array
     */
    public function getDefaultLatLong()
    {
        $helper = $this->_storelocatorHelper;
        $defaultLocation = $helper->getDefaultAddress();
        $defaultLatLong = [];

        //set default location by address
        if ($defaultLocation != '') {
            $address = urlencode($defaultLocation);
            $json = $helper->getJsonData($address);
            $defaultLatLong = [
                'lat' => strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'}),
                'long' => strval($json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'})
            ];
        }

        $data = $this->getRequest()->getParams();
        if ((!empty($data['q'])) || ($defaultLocation == '')) {
            //searching - display default by result
            if ($this->getStores()->getSize()) {
                $nearestStore = $this->getStores()->getFirstItem();
                $defaultLatLong = ['lat' => $nearestStore->getLatitude(), 'long' => $nearestStore->getLongitude()];
            }
        }

        if (empty($defaultLatLong)) {
            // if it is empty, set to a default location to avoid problem
            $defaultLatLong = ['lat' => '29.737354', 'long' => '-95.416767'];
        }

        return $defaultLatLong;
    }

    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    /**
     * @return bool
     */
    public function showEmailAndWebsite()
    {
        return $this->_storelocatorHelper->showEmailAndWebsite();
    }

    /**
     * @param  $lat1
     * @param  $lon1
     * @param  $lat2
     * @param  $lon2
     * @param  $unit
     * @return float
     */
    public function distance($lat1, $lon1, $lat2, $lon2, $unit)
    {
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        if ($unit == 1) {
            return ($miles * 1.609344);
        } else {
            return $miles;
        }
    }

    /**
     * @return string
     */
    public function getSearchRadiusUnit()
    {
        return $this->_storelocatorHelper->getRadiusUnit();
    }

    /**
     * @return array
     */
    public function getSearchRadiusOptions()
    {
        return $this->_storelocatorHelper->getSearchRadiusOptions();
    }

    /**
     * @return array
     */
    public function getListTag()
    {
        $storeCollection = $this->getStores();
        $storeIds = $storeCollection->getColumnValues('store_locator_id');

        $tagCollection = $this->_tagCollectionFactory->create()
            ->addFieldToFilter('store_locator_id', ['in' => $storeIds]);

        $tags = [];
        if (count($tagCollection)) {
            foreach ($tagCollection as $tag) {
                $_newTag = strtolower(trim($tag->getTag()));
                if (!in_array($_newTag, $tags)) {
                    $tags[] = $_newTag;
                }
            }
        }

        return $tags;
    }

    /**
     * Get components configuration
     *
     * @return array
     */
    public function getWidgetInitOptions()
    {
        return [
            'suggest' => [
                'template' => '[data-template=search-suggest]',
                'termAjaxArgument' => 'q',
                'source' => $this->getUrl('storelocator/index/storeSearch'),
                'filterProperty' => 'name',
                'valueField' => '#mb-query-search',
                'preventClickPropagation' => false,
                'minLength' => 2,
            ]
        ];
    }

    /**
     * @return string
     */
    public function getCommonIconUrl()
    {
        return $this->getViewFileUrl('Tigren_Storelocator::images/common_store_icon.png');
    }

    /**
     * @param  $icon
     * @return string
     * @throws NoSuchEntityException
     */
    public function getIconUrl($icon)
    {
        $iconUrl = $this->_storelocatorHelper->getIconUrl($icon);
        if (!$iconUrl) {
            $iconUrl = $this->getViewFileUrl('Tigren_Storelocator::images/default_store_icon.jpg');
        }
        return $iconUrl;
    }
}
