<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Block;

use Magento\Customer\Model\Session;
use Magento\Framework\Module\Manager;
use Magento\Framework\View\Element\Html\Link;
use Magento\Framework\View\Element\Template\Context;
use Tigren\Storelocator\Helper\Data;

/**
 * "Store" link
 *
 * @SuppressWarnings(PHPMD.DepthOfInheritance)
 */
class HeaderLink extends Link
{
    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * @var Manager
     */
    protected $_moduleManager;

    /**
     * @var Data
     */
    protected $_storelocatorHelper;

    /**
     * @param              Context $context
     * @param              Session $customerSession
     * @param              Manager $moduleManager
     * @param              Data    $storelocatorHelper
     * @param              array   $data
     * @codeCoverageIgnore
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        Manager $moduleManager,
        Data $storelocatorHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_storelocatorHelper = $storelocatorHelper;
        $this->_moduleManager = $moduleManager;
        $this->_customerSession = $customerSession;
    }

    /**
     * @return bool
     */
    public function isCustomerLoggedIn()
    {
        return (boolean)$this->_customerSession->isLoggedIn();
    }

    /**
     * @return             string
     * @codeCoverageIgnore
     */
    public function getHref()
    {
        return $this->getUrl('storelocator', ['_secure' => true]);
    }

    /**
     * @return             string
     * @codeCoverageIgnore
     */
    public function getLabel()
    {
        return __('Store Locator');
    }

    /**
     * Render block HTML
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (!$this->_storelocatorHelper->showTopLink() || !$this->_moduleManager->isOutputEnabled(
            'Tigren_Storelocator'
        )
        ) {
            return '';
        }
        return parent::_toHtml();
    }
}
