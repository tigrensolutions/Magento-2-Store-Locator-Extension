<?php
/**
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2019 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\Storelocator\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;

/**
 * Class Store
 *
 * @package Tigren\Storelocator\Block\Adminhtml
 */
class Store extends Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml_store';
        $this->_blockGroup = 'Tigren_Storelocator';
        $this->_headerText = __('Manage Stores');

        parent::_construct();

        if ($this->_isAllowedAction('Tigren_Storelocator::save')) {
            $this->buttonList->update('add', 'label', __('Add New Store'));
        } else {
            $this->buttonList->remove('add');
        }
    }

    /**
     * @param  $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
